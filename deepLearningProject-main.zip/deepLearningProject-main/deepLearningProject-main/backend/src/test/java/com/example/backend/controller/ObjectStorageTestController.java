package com.example.backend.controller;

public class ObjectStorageTestController {
}
